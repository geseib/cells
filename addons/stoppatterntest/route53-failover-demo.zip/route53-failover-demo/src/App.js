import React, { useEffect, useState } from 'react';
import ClientIcon from './components/ClientIcon';
import ConnectionLine from './components/ConnectionLine';
import ToggleFailoverSwitch from './components/ToggleFailoverSwitch';
import DNSQueryDisplay from './components/DNSQueryDisplay';

function App() {
  const [isPrimary, setIsPrimary] = useState(true);
  const [resolvedIP, setResolvedIP] = useState('1.1.1.1');

  const toggleFailover = async () => {
    const response = await fetch('YOUR_API_GATEWAY_URL_HERE', {
      method: 'POST',
      body: JSON.stringify({ failover: isPrimary }),
    });
    const data = await response.json();
    setIsPrimary(!isPrimary);
    resolveDNS();
  };

  const resolveDNS = async () => {
    const result = await fetch('/api/resolve');
    const { ip } = await result.json();
    setResolvedIP(ip);
  };

  useEffect(() => {
    resolveDNS();
  }, []);

  return (
    <div style={{ textAlign: 'center', marginTop: '2rem' }}>
      <ClientIcon />
      <ConnectionLine isPrimary={isPrimary} />
      <ToggleFailoverSwitch toggle={toggleFailover} isPrimary={isPrimary} />
      <DNSQueryDisplay ip={resolvedIP} />
    </div>
  );
}

export default App;
