import React from 'react';

function ClientIcon() {
  return (
    <div style={{ fontSize: '3rem' }}>
      🖥️
      <p>Client</p>
    </div>
  );
}

export default ClientIcon;
