import React from 'react';

function DNSQueryDisplay({ ip }) {
  return (
    <div style={{ marginTop: '2rem', fontFamily: 'monospace' }}>
      🔍 DNS Response: example.yourdomain.com → {ip}
    </div>
  );
}

export default DNSQueryDisplay;
